<h2><b>CONTACT US</b></h2>
<form method="post">
	<div class="row">
		<div class="col-md-8">
		<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>



	<div class="row">
		<div class="col-sm-4">Enter Your Email</div>
		<div class="col-sm-5">
		<input type="email" name="e" class="form-control"/></div>
	</div>

	<div class="row">
		<div class="col-sm-4">Enter Your Mobile</div>
		<div class="col-sm-5">
		<input type="password" name="p" class="form-control"/></div>
	</div>

	<div class="row">
		<div class="col-sm-4">Enter Your Message</div>
		<div class="col-sm-5">
		<input type="password" name="p" class="form-control"/></div>
	</div>

	<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		<input type="submit" value="Send Query" name="save" class="btn btn-success"/>

		</div>
	</div>

		</div>
		<div class="col-md-4">
		<h2>Contact us</h2>

		Name: Code-Projects<br/>
		Mobile: 9876543210<br/>
		Email:codeprojects@gmail.com<br/>
		Website: <a href="https://code-projects.org/">code-projects.org</a>
		</div>
	</div>


</form>
